import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * Problem 5: Real-Time Analytics Dashboard for Website Traffic
 * Concepts: Multiple HashMaps for different dimensions, frequency counting, top-N with PriorityQueue
 */
public class Problem5_AnalyticsDashboard {

    // Page URL → total view count
    private final Map<String, AtomicLong> pageViews = new ConcurrentHashMap<>();
    // Page URL → Set of unique userIds
    private final Map<String, Set<String>> uniqueVisitors = new ConcurrentHashMap<>();
    // Traffic source → count
    private final Map<String, AtomicLong> trafficSources = new ConcurrentHashMap<>();
    // Batch buffer for high-throughput processing
    private final List<PageViewEvent> buffer = Collections.synchronizedList(new ArrayList<>());
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    static class PageViewEvent {
        String url;
        String userId;
        String source;
        long timestamp;

        PageViewEvent(String url, String userId, String source) {
            this.url = url;
            this.userId = userId;
            this.source = source;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public Problem5_AnalyticsDashboard() {
        // Batch flush every 5 seconds
        scheduler.scheduleAtFixedRate(this::flushBuffer, 5, 5, TimeUnit.SECONDS);
    }

    /**
     * Receive a page view event
     */
    public void processEvent(String url, String userId, String source) {
        buffer.add(new PageViewEvent(url, userId, source));
        // For demo: also process immediately so stats are visible
        updateStats(url, userId, source);
    }

    private void updateStats(String url, String userId, String source) {
        // O(1) increment page view
        pageViews.computeIfAbsent(url, k -> new AtomicLong(0)).incrementAndGet();

        // O(1) unique visitor tracking
        uniqueVisitors.computeIfAbsent(url, k -> ConcurrentHashMap.newKeySet()).add(userId);

        // O(1) source count
        trafficSources.computeIfAbsent(source, k -> new AtomicLong(0)).incrementAndGet();
    }

    /**
     * Flush buffered events
     */
    private void flushBuffer() {
        List<PageViewEvent> batch;
        synchronized (buffer) {
            batch = new ArrayList<>(buffer);
            buffer.clear();
        }
        // In production: batch write to time-series DB
        System.out.println("[Batch flush] Processed " + batch.size() + " buffered events");
    }

    /**
     * Get top N pages using a min-heap (PriorityQueue) for O(n log k)
     */
    public List<Map.Entry<String, Long>> getTopPages(int n) {
        // Min-heap of size n
        PriorityQueue<Map.Entry<String, Long>> minHeap =
                new PriorityQueue<>(Comparator.comparingLong(Map.Entry::getValue));

        for (Map.Entry<String, AtomicLong> e : pageViews.entrySet()) {
            Map.Entry<String, Long> entry = Map.entry(e.getKey(), e.getValue().get());
            minHeap.offer(entry);
            if (minHeap.size() > n) minHeap.poll(); // evict smallest
        }

        List<Map.Entry<String, Long>> result = new ArrayList<>(minHeap);
        result.sort((a, b) -> Long.compare(b.getValue(), a.getValue())); // desc
        return result;
    }

    /**
     * Render the analytics dashboard
     */
    public void getDashboard() {
        System.out.println("\n===== ANALYTICS DASHBOARD =====");

        // Top pages
        System.out.println("\nTop Pages:");
        List<Map.Entry<String, Long>> topPages = getTopPages(5);
        for (int i = 0; i < topPages.size(); i++) {
            Map.Entry<String, Long> e = topPages.get(i);
            int unique = uniqueVisitors.getOrDefault(e.getKey(), Collections.emptySet()).size();
            System.out.printf("  %d. %-35s %,6d views  (%,d unique)%n",
                    i + 1, e.getKey(), e.getValue(), unique);
        }

        // Traffic sources
        System.out.println("\nTraffic Sources:");
        long totalSources = trafficSources.values().stream().mapToLong(AtomicLong::get).sum();
        trafficSources.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue().get(), a.getValue().get()))
                .forEach(e -> {
                    double pct = totalSources == 0 ? 0 : (e.getValue().get() * 100.0 / totalSources);
                    System.out.printf("  %-12s %5.1f%%%n", e.getKey() + ":", pct);
                });

        System.out.println("\nTotal page views: " + pageViews.values().stream().mapToLong(AtomicLong::get).sum());
        System.out.println("================================\n");
    }

    public static void main(String[] args) throws InterruptedException {
        Problem5_AnalyticsDashboard dashboard = new Problem5_AnalyticsDashboard();

        System.out.println("=== Problem 5: Real-Time Analytics Dashboard ===\n");

        String[] pages = {
            "/article/breaking-news", "/sports/championship", "/tech/ai-trends",
            "/politics/election", "/entertainment/movies"
        };
        String[] sources = {"google", "facebook", "direct", "twitter", "other"};
        Random rnd = new Random(42);

        // Simulate 1000 page view events
        for (int i = 0; i < 1000; i++) {
            String url = pages[rnd.nextInt(pages.length)];
            // Skew: breaking-news gets 3x more traffic
            if (rnd.nextInt(3) == 0) url = "/article/breaking-news";
            String source = sources[rnd.nextInt(sources.length)];
            // Skew google to ~45%
            if (rnd.nextInt(2) == 0) source = "google";
            dashboard.processEvent(url, "user_" + rnd.nextInt(500), source);
        }

        // Explicit events shown in problem spec
        dashboard.processEvent("/article/breaking-news", "user_123", "google");
        dashboard.processEvent("/article/breaking-news", "user_456", "facebook");

        dashboard.getDashboard();
        dashboard.scheduler.shutdown();
    }
}
