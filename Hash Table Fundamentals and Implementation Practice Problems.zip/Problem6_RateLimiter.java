import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Problem 6: Distributed Rate Limiter for API Gateway
 * Concepts: HashMap for client tracking, token bucket algorithm, time-based ops, thread safety
 */
public class Problem6_RateLimiter {

    /**
     * Token Bucket per client
     */
    static class TokenBucket {
        private final double maxTokens;
        private final double refillRate; // tokens per ms
        private double tokens;
        private long lastRefillTime;

        TokenBucket(double maxTokens, double refillRatePerHour) {
            this.maxTokens = maxTokens;
            this.refillRate = refillRatePerHour / (3600.0 * 1000); // per ms
            this.tokens = maxTokens; // start full
            this.lastRefillTime = System.currentTimeMillis();
        }

        synchronized boolean consume() {
            refill();
            if (tokens >= 1.0) {
                tokens -= 1.0;
                return true;
            }
            return false;
        }

        synchronized double getTokens() {
            refill();
            return tokens;
        }

        synchronized long getResetTimeMs() {
            // Time until bucket refills to max
            double needed = maxTokens - tokens;
            if (needed <= 0) return 0;
            return (long) (needed / refillRate);
        }

        private void refill() {
            long now = System.currentTimeMillis();
            double elapsed = now - lastRefillTime;
            double newTokens = elapsed * refillRate;
            tokens = Math.min(maxTokens, tokens + newTokens);
            lastRefillTime = now;
        }
    }

    private final Map<String, TokenBucket> buckets = new ConcurrentHashMap<>();
    private final double maxTokens;
    private final double refillRatePerHour;
    // Stats
    private final AtomicLong totalAllowed = new AtomicLong(0);
    private final AtomicLong totalDenied  = new AtomicLong(0);

    public Problem6_RateLimiter(int requestsPerHour) {
        this.maxTokens = requestsPerHour;
        this.refillRatePerHour = requestsPerHour;
    }

    /**
     * Check rate limit for a client - O(1)
     */
    public String checkRateLimit(String clientId) {
        TokenBucket bucket = buckets.computeIfAbsent(clientId,
                k -> new TokenBucket(maxTokens, refillRatePerHour));

        if (bucket.consume()) {
            totalAllowed.incrementAndGet();
            int remaining = (int) bucket.getTokens();
            return "Allowed (" + remaining + " requests remaining)";
        } else {
            totalDenied.incrementAndGet();
            long retryAfter = bucket.getResetTimeMs() / 1000;
            return "Denied (0 requests remaining, retry after " + retryAfter + "s)";
        }
    }

    /**
     * Get detailed status for a client
     */
    public Map<String, Object> getRateLimitStatus(String clientId) {
        TokenBucket bucket = buckets.get(clientId);
        if (bucket == null) {
            return Map.of("error", "Unknown client");
        }

        int used = (int)(maxTokens - bucket.getTokens());
        long resetEpoch = System.currentTimeMillis() / 1000 + bucket.getResetTimeMs() / 1000;

        Map<String, Object> status = new LinkedHashMap<>();
        status.put("used",   used);
        status.put("limit",  (int) maxTokens);
        status.put("remaining", (int) bucket.getTokens());
        status.put("reset",  resetEpoch);
        return status;
    }

    /**
     * Gateway statistics
     */
    public void printStats() {
        long total = totalAllowed.get() + totalDenied.get();
        System.out.printf("Gateway Stats: %,d total | %,d allowed (%.1f%%) | %,d denied (%.1f%%)%n",
                total,
                totalAllowed.get(), total == 0 ? 0 : totalAllowed.get() * 100.0 / total,
                totalDenied.get(),  total == 0 ? 0 : totalDenied.get()  * 100.0 / total);
        System.out.println("Active clients tracked: " + buckets.size());
    }

    public static void main(String[] args) throws InterruptedException {
        Problem6_RateLimiter limiter = new Problem6_RateLimiter(1000);

        System.out.println("=== Problem 6: Distributed Rate Limiter ===\n");

        // Normal usage
        System.out.println("checkRateLimit(\"abc123\") → " + limiter.checkRateLimit("abc123"));
        System.out.println("checkRateLimit(\"abc123\") → " + limiter.checkRateLimit("abc123"));
        System.out.println("checkRateLimit(\"xyz789\") → " + limiter.checkRateLimit("xyz789"));

        // Exhaust tokens for one client
        System.out.println("\n--- Exhausting 1000 tokens for client 'spammer' ---");
        for (int i = 0; i < 1000; i++) {
            limiter.checkRateLimit("spammer");
        }
        System.out.println("checkRateLimit(\"spammer\") → " + limiter.checkRateLimit("spammer"));
        System.out.println("getRateLimitStatus(\"spammer\") → " + limiter.getRateLimitStatus("spammer"));

        // Concurrent simulation
        System.out.println("\n--- Concurrent test: 10 clients × 200 requests ---");
        ExecutorService exec = Executors.newFixedThreadPool(20);
        CountDownLatch latch = new CountDownLatch(10 * 200);

        for (int c = 0; c < 10; c++) {
            final String clientId = "client_" + c;
            for (int r = 0; r < 200; r++) {
                exec.submit(() -> {
                    limiter.checkRateLimit(clientId);
                    latch.countDown();
                });
            }
        }

        latch.await(10, TimeUnit.SECONDS);
        exec.shutdown();

        System.out.println();
        limiter.printStats();
    }
}
