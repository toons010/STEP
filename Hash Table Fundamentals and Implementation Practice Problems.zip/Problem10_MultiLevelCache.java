import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Problem 10: Multi-Level Cache System with Hash Tables
 * Concepts: Multiple HashMaps, LRU eviction, rehashing/resizing, cache promotion, hit ratio tracking
 */
public class Problem10_MultiLevelCache {

    static class VideoData {
        String videoId;
        String title;
        byte[] payload; // simulated content
        int    accessCount;

        VideoData(String videoId, String title) {
            this.videoId     = videoId;
            this.title       = title;
            this.payload     = new byte[1024]; // 1KB placeholder
            this.accessCount = 0;
        }
        @Override public String toString() { return "[Video: " + videoId + " | " + title + "]"; }
    }

    // ── L1: In-memory LRU (LinkedHashMap, access-order, max 10 entries for demo) ──
    private static final int L1_CAPACITY = 10;
    private final LinkedHashMap<String, VideoData> l1Cache;

    // ── L2: "SSD-backed" (HashMap, max 50 entries for demo) ──
    private static final int L2_CAPACITY  = 50;
    private static final int L2_PROMOTE_THRESHOLD = 3; // promote to L1 after 3 hits
    private final Map<String, VideoData> l2Cache = new LinkedHashMap<>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, VideoData> eldest) {
            return size() > L2_CAPACITY;
        }
    };

    // ── L3: Simulated database (all videos) ──
    private final Map<String, VideoData> l3Database = new HashMap<>();

    // ── Access counts for promotion decisions ──
    private final Map<String, AtomicLong> accessCounts = new HashMap<>();

    // ── Stats ──
    private final AtomicLong l1Hits   = new AtomicLong(0);
    private final AtomicLong l2Hits   = new AtomicLong(0);
    private final AtomicLong l3Hits   = new AtomicLong(0);
    private final AtomicLong misses   = new AtomicLong(0);
    private final AtomicLong l1Time   = new AtomicLong(0);
    private final AtomicLong l2Time   = new AtomicLong(0);
    private final AtomicLong l3Time   = new AtomicLong(0);
    private final AtomicLong l1Reqs   = new AtomicLong(0);
    private final AtomicLong l2Reqs   = new AtomicLong(0);
    private final AtomicLong l3Reqs   = new AtomicLong(0);

    public Problem10_MultiLevelCache() {
        l1Cache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override protected boolean removeEldestEntry(Map.Entry<String, VideoData> eldest) {
                if (size() > L1_CAPACITY) {
                    // Demote evicted entry to L2
                    l2Cache.put(eldest.getKey(), eldest.getValue());
                    return true;
                }
                return false;
            }
        };
        // Seed L3 database
        for (int i = 1; i <= 200; i++) {
            String id = "video_" + i;
            l3Database.put(id, new VideoData(id, "Title #" + i));
        }
    }

    /**
     * Get a video, checking L1 → L2 → L3 in order
     */
    public String getVideo(String videoId) {
        long start = nanoNow();
        StringBuilder trace = new StringBuilder();

        // ── L1 Check ──
        VideoData data = l1Cache.get(videoId);
        if (data != null) {
            l1Hits.incrementAndGet();
            long elapsed = nanoNow() - start;
            l1Time.addAndGet(elapsed); l1Reqs.incrementAndGet();
            incrementAccess(videoId);
            trace.append(String.format("→ L1 Cache HIT (%.2fms)%n", elapsed / 1e6));
            trace.append("→ Data: ").append(data);
            return trace.toString();
        }
        trace.append(String.format("→ L1 Cache MISS (%.2fms)%n", (nanoNow() - start) / 1e6));
        l1Reqs.incrementAndGet();

        // ── L2 Check ──
        long l2Start = nanoNow();
        data = l2Cache.get(videoId);
        long l2Elapsed = nanoNow() - l2Start;
        l2Time.addAndGet(l2Elapsed); l2Reqs.incrementAndGet();

        if (data != null) {
            l2Hits.incrementAndGet();
            long count = incrementAccess(videoId);
            trace.append(String.format("→ L2 Cache HIT (%.2fms)%n", l2Elapsed / 1e6));
            if (count >= L2_PROMOTE_THRESHOLD) {
                l1Cache.put(videoId, data);
                trace.append("→ Promoted to L1 (access count: ").append(count).append(")");
            }
            return trace.toString();
        }
        trace.append(String.format("→ L2 Cache MISS (%.2fms)%n", l2Elapsed / 1e6));

        // ── L3 Check (database) ──
        long l3Start = nanoNow();
        simulateDiskLatency(150); // simulate 150ms DB lookup
        data = l3Database.get(videoId);
        long l3Elapsed = nanoNow() - l3Start;
        l3Time.addAndGet(l3Elapsed); l3Reqs.incrementAndGet();

        if (data != null) {
            l3Hits.incrementAndGet();
            incrementAccess(videoId);
            l2Cache.put(videoId, data); // warm L2
            trace.append(String.format("→ L3 Database HIT (%.0fms)%n", l3Elapsed / 1e6));
            trace.append("→ Added to L2 (access count: 1)");
            return trace.toString();
        }

        misses.incrementAndGet();
        return trace + "→ NOT FOUND";
    }

    /**
     * Invalidate a video from all cache levels (e.g., content updated)
     */
    public void invalidate(String videoId) {
        l1Cache.remove(videoId);
        l2Cache.remove(videoId);
        accessCounts.remove(videoId);
        System.out.println("Invalidated \"" + videoId + "\" from all cache levels");
    }

    private long incrementAccess(String videoId) {
        return accessCounts.computeIfAbsent(videoId, k -> new AtomicLong(0))
                .incrementAndGet();
    }

    private long nanoNow() { return System.nanoTime(); }

    private void simulateDiskLatency(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    /**
     * Print cache statistics
     */
    public void getStatistics() {
        System.out.println("\ngetStatistics() →");

        long totalReqs = l1Reqs.get() + l2Reqs.get() + l3Reqs.get();

        printLevel("L1", l1Hits.get(), l1Reqs.get(), l1Time.get());
        printLevel("L2", l2Hits.get(), l2Reqs.get(), l2Time.get());
        printLevel("L3", l3Hits.get(), l3Reqs.get(), l3Time.get());

        long totalHits = l1Hits.get() + l2Hits.get() + l3Hits.get();
        long totalLookups = totalHits + misses.get();
        double overallHitRate = totalLookups == 0 ? 0 : totalHits * 100.0 / totalLookups;
        long totalTimeNs = l1Time.get() + l2Time.get() + l3Time.get();
        double avgTime = totalLookups == 0 ? 0 : totalTimeNs / (1e6 * totalLookups);

        System.out.printf("  Overall: Hit Rate %.0f%%, Avg Time: %.1fms%n", overallHitRate, avgTime);
        System.out.println("\n  L1 size: " + l1Cache.size() + "/" + L1_CAPACITY);
        System.out.println("  L2 size: " + l2Cache.size() + "/" + L2_CAPACITY);
        System.out.println("  L3 (DB) size: " + l3Database.size());
    }

    private void printLevel(String level, long hits, long reqs, long timeNs) {
        double hitRate = reqs == 0 ? 0 : hits * 100.0 / reqs;
        double avgTime = reqs == 0 ? 0 : timeNs / (1e6 * reqs);
        System.out.printf("  %s: Hit Rate %.0f%%, Avg Time: %.2fms%n", level, hitRate, avgTime);
    }

    public static void main(String[] args) throws InterruptedException {
        Problem10_MultiLevelCache cache = new Problem10_MultiLevelCache();

        System.out.println("=== Problem 10: Multi-Level Cache System ===\n");

        // Cold miss → L3
        System.out.println("--- getVideo(\"video_123\") [cold] ---");
        System.out.println(cache.getVideo("video_123"));

        // Warm hit → L2 (loaded from L3 on previous call)
        System.out.println("\n--- getVideo(\"video_123\") [second request] ---");
        System.out.println(cache.getVideo("video_123"));

        // Promote to L1 after 3+ accesses
        System.out.println("\n--- getVideo(\"video_123\") [third request - should promote] ---");
        System.out.println(cache.getVideo("video_123"));

        System.out.println("\n--- getVideo(\"video_123\") [fourth request - L1 hit] ---");
        System.out.println(cache.getVideo("video_123"));

        // Another cold miss
        System.out.println("\n--- getVideo(\"video_999\") [cold miss] ---");
        System.out.println(cache.getVideo("video_999"));

        // Not in DB
        System.out.println("\n--- getVideo(\"video_9999\") [not found] ---");
        System.out.println(cache.getVideo("video_9999"));

        // Cache invalidation
        System.out.println();
        cache.invalidate("video_123");
        System.out.println("After invalidation: getVideo(\"video_123\")");
        System.out.println(cache.getVideo("video_123"));

        cache.getStatistics();
    }
}
