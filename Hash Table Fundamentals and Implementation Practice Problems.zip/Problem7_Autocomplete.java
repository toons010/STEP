import java.util.*;

/**
 * Problem 7: Autocomplete System for Search Engine
 * Concepts: Trie + HashMap hybrid, string hashing, prefix search, min-heap for top-K
 */
public class Problem7_Autocomplete {

    /**
     * Trie Node - each node holds a HashMap of children + frequency
     */
    static class TrieNode {
        Map<Character, TrieNode> children = new HashMap<>();
        boolean isEndOfWord = false;
        int frequency = 0;
        String fullQuery = null; // stored at terminal node
    }

    private final TrieNode root = new TrieNode();
    // Global frequency map for O(1) frequency lookup/update
    private final Map<String, Integer> frequencyMap = new HashMap<>();
    // Prefix → top suggestions cache (invalidated on updates)
    private final Map<String, List<String>> prefixCache = new HashMap<>();

    /**
     * Insert or update a query's frequency
     */
    public void insert(String query, int frequency) {
        frequencyMap.put(query, frequency);
        prefixCache.clear(); // invalidate cache

        TrieNode current = root;
        for (char c : query.toCharArray()) {
            current.children.putIfAbsent(c, new TrieNode());
            current = current.children.get(c);
        }
        current.isEndOfWord = true;
        current.frequency  = frequency;
        current.fullQuery  = query;
    }

    /**
     * Update frequency of an existing query (e.g., after a new search)
     */
    public void updateFrequency(String query) {
        int newFreq = frequencyMap.merge(query, 1, Integer::sum);
        prefixCache.clear();

        TrieNode current = root;
        for (char c : query.toCharArray()) {
            if (!current.children.containsKey(c)) {
                insert(query, newFreq);
                return;
            }
            current = current.children.get(c);
        }
        if (current.isEndOfWord) {
            current.frequency = newFreq;
        }
        System.out.println("updateFrequency(\"" + query + "\") → Frequency: " + (newFreq - 1) + " → " + newFreq
                + (newFreq <= 5 ? " (trending)" : ""));
    }

    /**
     * Return top-K suggestions for a prefix using Trie traversal + min-heap
     */
    public List<String> search(String prefix, int topK) {
        // Check cache first
        String cacheKey = prefix + ":" + topK;
        if (prefixCache.containsKey(cacheKey)) {
            return prefixCache.get(cacheKey);
        }

        // Navigate to prefix node
        TrieNode current = root;
        for (char c : prefix.toCharArray()) {
            if (!current.children.containsKey(c)) {
                return Collections.emptyList(); // Prefix not found
            }
            current = current.children.get(c);
        }

        // Collect all completions using min-heap (size = topK)
        PriorityQueue<Map.Entry<String, Integer>> minHeap =
                new PriorityQueue<>(Comparator.comparingInt(Map.Entry::getValue));

        collectCompletions(current, prefix, minHeap, topK);

        // Drain heap into sorted list (descending by frequency)
        List<Map.Entry<String, Integer>> results = new ArrayList<>(minHeap);
        results.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        List<String> suggestions = new ArrayList<>();
        for (Map.Entry<String, Integer> e : results) {
            suggestions.add(e.getKey() + " (" + String.format("%,d", e.getValue()) + " searches)");
        }

        prefixCache.put(cacheKey, suggestions);
        return suggestions;
    }

    /**
     * DFS to collect all word completions from a Trie node
     */
    private void collectCompletions(TrieNode node, String currentPrefix,
                                    PriorityQueue<Map.Entry<String, Integer>> heap, int k) {
        if (node.isEndOfWord) {
            heap.offer(Map.entry(node.fullQuery, node.frequency));
            if (heap.size() > k) heap.poll(); // keep only top-k
        }
        for (Map.Entry<Character, TrieNode> child : node.children.entrySet()) {
            collectCompletions(child.getValue(), currentPrefix + child.getKey(), heap, k);
        }
    }

    /**
     * Simple edit-distance based typo suggestion (Levenshtein distance 1)
     */
    public List<String> suggestCorrections(String misspelled) {
        List<String> candidates = new ArrayList<>();
        for (String query : frequencyMap.keySet()) {
            if (editDistance(misspelled, query) <= 1) {
                candidates.add(query);
            }
        }
        candidates.sort((a, b) -> frequencyMap.get(b) - frequencyMap.get(a));
        return candidates.subList(0, Math.min(3, candidates.size()));
    }

    private int editDistance(String a, String b) {
        int m = a.length(), n = b.length();
        int[][] dp = new int[m + 1][n + 1];
        for (int i = 0; i <= m; i++) dp[i][0] = i;
        for (int j = 0; j <= n; j++) dp[0][j] = j;
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = a.charAt(i-1) == b.charAt(j-1) ? dp[i-1][j-1]
                        : 1 + Math.min(dp[i-1][j-1], Math.min(dp[i-1][j], dp[i][j-1]));
        return dp[m][n];
    }

    public static void main(String[] args) {
        Problem7_Autocomplete ac = new Problem7_Autocomplete();

        System.out.println("=== Problem 7: Autocomplete System ===\n");

        // Seed with common queries
        ac.insert("java tutorial",       1_234_567);
        ac.insert("javascript",          987_654);
        ac.insert("java download",       456_789);
        ac.insert("java 21 features",    1);
        ac.insert("java interview questions", 345_000);
        ac.insert("java spring boot",    280_000);
        ac.insert("python tutorial",     900_000);
        ac.insert("python download",     300_000);
        ac.insert("javascript tutorial", 750_000);

        // Search
        System.out.println("search(\"jav\") →");
        ac.search("jav", 10).forEach(s -> System.out.println("  " + s));

        System.out.println("\nsearch(\"java \") →");
        ac.search("java ", 5).forEach(s -> System.out.println("  " + s));

        System.out.println("\nsearch(\"py\") →");
        ac.search("py", 5).forEach(s -> System.out.println("  " + s));

        // Update frequency (trending)
        System.out.println();
        ac.updateFrequency("java 21 features");
        ac.updateFrequency("java 21 features");

        System.out.println("\nAfter updates, search(\"java 21\") →");
        ac.search("java 21", 5).forEach(s -> System.out.println("  " + s));

        // Typo correction
        System.out.println("\nsuggestCorrections(\"javaa\") → " + ac.suggestCorrections("javaa"));
    }
}
