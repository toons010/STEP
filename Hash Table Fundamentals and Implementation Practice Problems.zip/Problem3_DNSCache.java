import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Problem 3: DNS Cache with TTL (Time To Live)
 * Concepts: Custom Entry class, chaining for collision resolution, time-based ops, LRU eviction
 */
public class Problem3_DNSCache {

    /**
     * DNS Entry with TTL tracking
     */
    static class DNSEntry {
        String domain;
        String ipAddress;
        long insertedAt;   // ms
        long ttlMillis;    // ms

        DNSEntry(String domain, String ipAddress, long ttlSeconds) {
            this.domain = domain;
            this.ipAddress = ipAddress;
            this.insertedAt = System.currentTimeMillis();
            this.ttlMillis = ttlSeconds * 1000;
        }

        boolean isExpired() {
            return System.currentTimeMillis() - insertedAt > ttlMillis;
        }

        long remainingTTL() {
            long remaining = ttlMillis - (System.currentTimeMillis() - insertedAt);
            return Math.max(0, remaining / 1000);
        }
    }

    private final int maxCapacity;
    // LRU cache: LinkedHashMap in access-order
    private final LinkedHashMap<String, DNSEntry> cache;
    private final AtomicLong hits = new AtomicLong(0);
    private final AtomicLong misses = new AtomicLong(0);
    private final AtomicLong totalLookupTime = new AtomicLong(0);
    private final AtomicLong lookupCount = new AtomicLong(0);

    // Simulated upstream DNS (for demo purposes)
    private final Map<String, String> upstreamDNS = new HashMap<>();

    public Problem3_DNSCache(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        this.cache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, DNSEntry> eldest) {
                return size() > maxCapacity; // LRU eviction
            }
        };

        // Seed upstream DNS
        upstreamDNS.put("google.com",    "172.217.14.206");
        upstreamDNS.put("facebook.com",  "157.240.11.35");
        upstreamDNS.put("amazon.com",    "176.32.103.205");
        upstreamDNS.put("github.com",    "140.82.121.4");

        // Background cleanup thread for expired entries
        ScheduledExecutorService cleaner = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "dns-cache-cleaner");
            t.setDaemon(true);
            return t;
        });
        cleaner.scheduleAtFixedRate(this::removeExpiredEntries, 5, 5, TimeUnit.SECONDS);
    }

    /**
     * Resolve domain to IP - checks cache first, then upstream DNS
     */
    public String resolve(String domain) {
        long start = System.nanoTime();
        String result;

        synchronized (cache) {
            DNSEntry entry = cache.get(domain);

            if (entry != null && !entry.isExpired()) {
                hits.incrementAndGet();
                result = "[CACHE HIT] " + entry.ipAddress + " (TTL remaining: " + entry.remainingTTL() + "s)";
            } else {
                if (entry != null) {
                    cache.remove(domain);
                    result = queryUpstream(domain, "[CACHE EXPIRED] ");
                } else {
                    misses.incrementAndGet();
                    result = queryUpstream(domain, "[CACHE MISS] ");
                }
            }
        }

        long elapsed = (System.nanoTime() - start) / 1_000; // microseconds
        totalLookupTime.addAndGet(elapsed);
        lookupCount.incrementAndGet();

        return result + " [" + elapsed + "µs]";
    }

    private String queryUpstream(String domain, String prefix) {
        String ip = upstreamDNS.getOrDefault(domain, "NXDOMAIN");
        if (!ip.equals("NXDOMAIN")) {
            cache.put(domain, new DNSEntry(domain, ip, 300)); // 300s TTL
        }
        misses.incrementAndGet();
        return prefix + "Query upstream → " + ip + " (TTL: 300s)";
    }

    /**
     * Remove all expired entries (background cleanup)
     */
    private void removeExpiredEntries() {
        synchronized (cache) {
            cache.entrySet().removeIf(e -> e.getValue().isExpired());
        }
    }

    /**
     * Cache statistics
     */
    public String getCacheStats() {
        long total = hits.get() + misses.get();
        double hitRate = total == 0 ? 0 : (hits.get() * 100.0 / total);
        double avgTime = lookupCount.get() == 0 ? 0 : (totalLookupTime.get() / (double) lookupCount.get());
        return String.format("Hit Rate: %.1f%%, Avg Lookup Time: %.1fµs, Cache Size: %d/%d",
                hitRate, avgTime, cache.size(), maxCapacity);
    }

    /**
     * Add entry directly (e.g., from upstream response)
     */
    public void addEntry(String domain, String ip, long ttlSeconds) {
        synchronized (cache) {
            cache.put(domain, new DNSEntry(domain, ip, ttlSeconds));
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Problem3_DNSCache dns = new Problem3_DNSCache(1000);

        System.out.println("=== Problem 3: DNS Cache with TTL ===\n");

        // Miss: first lookup
        System.out.println("resolve(\"google.com\")   → " + dns.resolve("google.com"));
        // Hit: second lookup
        System.out.println("resolve(\"google.com\")   → " + dns.resolve("google.com"));
        System.out.println("resolve(\"facebook.com\") → " + dns.resolve("facebook.com"));
        System.out.println("resolve(\"github.com\")   → " + dns.resolve("github.com"));
        System.out.println("resolve(\"github.com\")   → " + dns.resolve("github.com"));
        System.out.println("resolve(\"github.com\")   → " + dns.resolve("github.com"));

        // Simulate expired entry
        System.out.println("\n--- Simulating expired entry ---");
        dns.addEntry("expired.com", "1.2.3.4", 0); // 0s TTL = already expired
        Thread.sleep(10);
        System.out.println("resolve(\"expired.com\") → " + dns.resolve("expired.com"));

        // Unknown domain
        System.out.println("resolve(\"unknown.xyz\") → " + dns.resolve("unknown.xyz"));

        System.out.println("\ngetCacheStats() → " + dns.getCacheStats());
    }
}
