import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Problem 2: E-commerce Flash Sale Inventory Manager
 * Concepts: HashMap for stock lookup, collision resolution, load factor, atomic operations
 */
public class Problem2_InventoryManager {

    // productId -> stock count (ConcurrentHashMap for thread safety)
    private final Map<String, AtomicInteger> inventory = new ConcurrentHashMap<>();
    // productId -> waiting list (FIFO using LinkedList)
    private final Map<String, Queue<Integer>> waitingLists = new ConcurrentHashMap<>();

    public Problem2_InventoryManager() {
        // Initialize products
        inventory.put("IPHONE15_256GB", new AtomicInteger(100));
        inventory.put("MACBOOK_PRO_M3", new AtomicInteger(50));
        inventory.put("AIRPODS_PRO2", new AtomicInteger(200));
    }

    /**
     * O(1) stock check
     */
    public int checkStock(String productId) {
        AtomicInteger stock = inventory.get(productId);
        return (stock != null) ? stock.get() : -1;
    }

    /**
     * Atomic purchase to prevent overselling
     */
    public String purchaseItem(String productId, int userId) {
        AtomicInteger stock = inventory.get(productId);
        if (stock == null) {
            return "Product not found: " + productId;
        }

        // Atomically decrement only if stock > 0
        int current;
        do {
            current = stock.get();
            if (current <= 0) {
                // Add to waiting list
                waitingLists.computeIfAbsent(productId, k -> new LinkedList<>()).add(userId);
                int position = ((Queue<?>) waitingLists.get(productId)).size();
                return "Added to waiting list, position #" + position;
            }
        } while (!stock.compareAndSet(current, current - 1));

        return "Success, " + (current - 1) + " units remaining";
    }

    /**
     * Restock and notify waitlist
     */
    public void restock(String productId, int units) {
        inventory.computeIfAbsent(productId, k -> new AtomicInteger(0)).addAndGet(units);
        Queue<Integer> waiting = waitingLists.get(productId);
        if (waiting != null && !waiting.isEmpty()) {
            System.out.println("Notifying " + Math.min(units, waiting.size()) + " users from waitlist for " + productId);
        }
    }

    /**
     * Get waiting list size
     */
    public int getWaitlistSize(String productId) {
        Queue<Integer> q = waitingLists.get(productId);
        return (q != null) ? q.size() : 0;
    }

    public static void main(String[] args) throws InterruptedException {
        Problem2_InventoryManager manager = new Problem2_InventoryManager();

        System.out.println("=== Problem 2: Flash Sale Inventory Manager ===\n");

        System.out.println("checkStock(\"IPHONE15_256GB\") → " + manager.checkStock("IPHONE15_256GB") + " units available");

        System.out.println("\npurchaseItem(\"IPHONE15_256GB\", 12345) → " + manager.purchaseItem("IPHONE15_256GB", 12345));
        System.out.println("purchaseItem(\"IPHONE15_256GB\", 67890) → " + manager.purchaseItem("IPHONE15_256GB", 67890));

        // Simulate buying out stock (buy remaining 98 units)
        for (int i = 3; i <= 100; i++) {
            manager.purchaseItem("IPHONE15_256GB", 10000 + i);
        }

        System.out.println("\nAfter 100 purchases, stock: " + manager.checkStock("IPHONE15_256GB"));
        System.out.println("purchaseItem(\"IPHONE15_256GB\", 99999) → " + manager.purchaseItem("IPHONE15_256GB", 99999));
        System.out.println("purchaseItem(\"IPHONE15_256GB\", 88888) → " + manager.purchaseItem("IPHONE15_256GB", 88888));
        System.out.println("Waitlist size: " + manager.getWaitlistSize("IPHONE15_256GB"));

        // Concurrent simulation
        System.out.println("\n--- Concurrent Purchase Simulation (10 threads, AIRPODS_PRO2) ---");
        ExecutorService executor = Executors.newFixedThreadPool(10);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger waitlistCount = new AtomicInteger(0);

        for (int i = 0; i < 250; i++) {
            final int userId = i;
            executor.submit(() -> {
                String result = manager.purchaseItem("AIRPODS_PRO2", userId);
                if (result.startsWith("Success")) successCount.incrementAndGet();
                else waitlistCount.incrementAndGet();
            });
        }
        executor.shutdown();
        executor.awaitTermination(5, TimeUnit.SECONDS);

        System.out.println("Successful purchases: " + successCount.get() + " (expected 200)");
        System.out.println("Waitlisted: " + waitlistCount.get() + " (expected 50)");
        System.out.println("Remaining stock: " + manager.checkStock("AIRPODS_PRO2") + " (expected 0)");
    }
}
