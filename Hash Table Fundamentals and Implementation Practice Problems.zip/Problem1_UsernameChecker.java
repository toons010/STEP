import java.util.*;

/**
 * Problem 1: Social Media Username Availability Checker
 * Concepts: Hash table basics, O(1) lookup, collision handling, frequency counting
 */
public class Problem1_UsernameChecker {

    // username -> userId mapping
    private final Map<String, Integer> registeredUsers = new HashMap<>();
    // username -> attempt count
    private final Map<String, Integer> attemptFrequency = new HashMap<>();

    public Problem1_UsernameChecker() {
        // Pre-populate with some existing users
        registeredUsers.put("john_doe", 1001);
        registeredUsers.put("admin", 1002);
        registeredUsers.put("superuser", 1003);
        registeredUsers.put("jane", 1004);
    }

    /**
     * O(1) lookup using HashMap
     */
    public boolean checkAvailability(String username) {
        // Track attempt frequency
        attemptFrequency.merge(username, 1, Integer::sum);
        return !registeredUsers.containsKey(username);
    }

    /**
     * Register a new username
     */
    public boolean register(String username, int userId) {
        if (registeredUsers.containsKey(username)) {
            return false; // Already taken
        }
        registeredUsers.put(username, userId);
        return true;
    }

    /**
     * Suggest 3 alternative usernames if the requested one is taken
     */
    public List<String> suggestAlternatives(String username) {
        List<String> suggestions = new ArrayList<>();

        // Strategy 1: Append numbers
        for (int i = 1; suggestions.size() < 2; i++) {
            String candidate = username + i;
            if (!registeredUsers.containsKey(candidate)) {
                suggestions.add(candidate);
            }
        }

        // Strategy 2: Replace underscore with dot
        String dotVersion = username.replace("_", ".");
        if (!registeredUsers.containsKey(dotVersion) && !dotVersion.equals(username)) {
            suggestions.add(dotVersion);
        } else {
            // Strategy 3: Prepend "the_"
            String prefixed = "the_" + username;
            if (!registeredUsers.containsKey(prefixed)) {
                suggestions.add(prefixed);
            }
        }

        return suggestions;
    }

    /**
     * Return the most attempted username using HashMap frequency tracking
     */
    public String getMostAttempted() {
        return attemptFrequency.entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .map(e -> e.getKey() + " (" + e.getValue() + " attempts)")
                .orElse("No attempts yet");
    }

    public static void main(String[] args) {
        Problem1_UsernameChecker checker = new Problem1_UsernameChecker();

        System.out.println("=== Problem 1: Username Availability Checker ===\n");

        System.out.println("checkAvailability(\"john_doe\")   → " + checker.checkAvailability("john_doe"));
        System.out.println("checkAvailability(\"jane_smith\") → " + checker.checkAvailability("jane_smith"));
        System.out.println("checkAvailability(\"admin\")      → " + checker.checkAvailability("admin"));
        System.out.println("checkAvailability(\"admin\")      → " + checker.checkAvailability("admin")); // 2nd attempt

        System.out.println("\nsuggestAlternatives(\"john_doe\") → " + checker.suggestAlternatives("john_doe"));

        System.out.println("\ngetMostAttempted() → " + checker.getMostAttempted());

        // Register a new user
        System.out.println("\nregister(\"jane_smith\", 9001) → " + checker.register("jane_smith", 9001));
        System.out.println("checkAvailability(\"jane_smith\") → " + checker.checkAvailability("jane_smith"));
    }
}
