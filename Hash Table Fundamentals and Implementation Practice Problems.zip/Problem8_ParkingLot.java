import java.util.*;

/**
 * Problem 8: Parking Lot Management with Open Addressing
 * Concepts: Open addressing (linear probing), custom hash function, load factor, EMPTY/OCCUPIED/DELETED
 */
public class Problem8_ParkingLot {

    enum SpotStatus { EMPTY, OCCUPIED, DELETED }

    static class ParkingSpot {
        SpotStatus status = SpotStatus.EMPTY;
        String licensePlate = null;
        long entryTime  = 0;
        int  spotNumber = 0;
    }

    static class ParkingSession {
        String licensePlate;
        int    spotNumber;
        long   entryTime;
        ParkingSession(String plate, int spot, long entryTime) {
            this.licensePlate = plate;
            this.spotNumber   = spot;
            this.entryTime    = entryTime;
        }
    }

    private static final double HOURLY_RATE    = 5.0;
    private static final double MAX_LOAD_FACTOR = 0.7;

    private final ParkingSpot[] spots;
    private final int capacity;
    private int occupied = 0;

    // licensePlate → session (for O(1) exit lookup)
    private final Map<String, ParkingSession> sessions = new HashMap<>();

    // Stats tracking
    private long totalProbes    = 0;
    private long totalParkings  = 0;
    private final Map<Integer, Integer> hourHistogram = new HashMap<>(); // hour → count

    public Problem8_ParkingLot(int capacity) {
        this.capacity = capacity;
        this.spots    = new ParkingSpot[capacity];
        for (int i = 0; i < capacity; i++) {
            spots[i] = new ParkingSpot();
            spots[i].spotNumber = i;
        }
    }

    /**
     * Hash function: license plate → preferred spot number
     */
    private int hash(String licensePlate) {
        int h = 0;
        for (char c : licensePlate.toCharArray()) {
            h = h * 31 + c;
        }
        return Math.abs(h) % capacity;
    }

    /**
     * Park a vehicle using linear probing
     */
    public String parkVehicle(String licensePlate) {
        if ((double) occupied / capacity >= MAX_LOAD_FACTOR) {
            return "Parking lot is full (load factor exceeded)";
        }
        if (sessions.containsKey(licensePlate)) {
            return licensePlate + " is already parked at spot #" + sessions.get(licensePlate).spotNumber;
        }

        int preferred = hash(licensePlate);
        int probes = 0;
        int idx = preferred;

        // Linear probing
        while (spots[idx].status == SpotStatus.OCCUPIED) {
            idx = (idx + 1) % capacity;
            probes++;
            if (probes >= capacity) return "No available spots!";
        }

        // Assign spot
        spots[idx].status       = SpotStatus.OCCUPIED;
        spots[idx].licensePlate = licensePlate;
        spots[idx].entryTime    = System.currentTimeMillis();
        occupied++;
        totalProbes   += probes;
        totalParkings++;

        // Track hour histogram
        int hour = java.time.LocalTime.now().getHour();
        hourHistogram.merge(hour, 1, Integer::sum);

        ParkingSession session = new ParkingSession(licensePlate, idx, spots[idx].entryTime);
        sessions.put(licensePlate, session);

        String probeStr = probes == 0 ? "0 probes" : probes + " probe" + (probes > 1 ? "s" : "");
        return String.format("Assigned spot #%d (preferred #%d, %s)", idx, preferred, probeStr);
    }

    /**
     * Exit vehicle and compute fee
     */
    public String exitVehicle(String licensePlate) {
        ParkingSession session = sessions.get(licensePlate);
        if (session == null) {
            return licensePlate + " not found in parking lot";
        }

        long durationMs = System.currentTimeMillis() - session.entryTime;
        double hours    = Math.max(durationMs / 3_600_000.0, 1.0 / 60); // min 1 min billing
        double fee      = Math.ceil(hours) * HOURLY_RATE;

        // Mark as DELETED (not EMPTY) for open addressing tombstone
        int idx = session.spotNumber;
        spots[idx].status       = SpotStatus.DELETED;
        spots[idx].licensePlate = null;
        occupied--;
        sessions.remove(licensePlate);

        long mins  = (durationMs / 1000) / 60;
        long secs  = (durationMs / 1000) % 60;
        return String.format("Spot #%d freed, Duration: %dm %ds, Fee: $%.2f", idx, mins, secs, fee);
    }

    /**
     * Find the nearest available spot to entrance (spot 0)
     */
    public int findNearestAvailableSpot() {
        for (int i = 0; i < capacity; i++) {
            if (spots[i].status != SpotStatus.OCCUPIED) return i;
        }
        return -1;
    }

    /**
     * Parking statistics
     */
    public void getStatistics() {
        double occupancy    = (double) occupied / capacity * 100;
        double avgProbes    = totalParkings == 0 ? 0 : (double) totalProbes / totalParkings;
        int peakHour        = hourHistogram.entrySet().stream()
                                .max(Map.Entry.comparingByValue())
                                .map(Map.Entry::getKey).orElse(-1);

        System.out.printf("Occupancy: %.0f%% (%d/%d), Avg Probes: %.1f, Peak Hour: %s%n",
                occupancy, occupied, capacity, avgProbes,
                peakHour < 0 ? "N/A" : peakHour + ":00-" + (peakHour + 1) + ":00");
        System.out.println("Load factor: " + String.format("%.2f", (double) occupied / capacity)
                + " (threshold: " + MAX_LOAD_FACTOR + ")");
    }

    public static void main(String[] args) throws InterruptedException {
        Problem8_ParkingLot lot = new Problem8_ParkingLot(500);

        System.out.println("=== Problem 8: Parking Lot with Open Addressing ===\n");

        System.out.println("parkVehicle(\"ABC-1234\") → " + lot.parkVehicle("ABC-1234"));
        System.out.println("parkVehicle(\"ABC-1235\") → " + lot.parkVehicle("ABC-1235"));
        System.out.println("parkVehicle(\"XYZ-9999\") → " + lot.parkVehicle("XYZ-9999"));
        System.out.println("parkVehicle(\"DEF-5678\") → " + lot.parkVehicle("DEF-5678"));

        System.out.println("\nNearest available spot: #" + lot.findNearestAvailableSpot());

        // Simulate brief parking duration
        Thread.sleep(100);

        System.out.println("\nexitVehicle(\"ABC-1234\") → " + lot.exitVehicle("ABC-1234"));

        // Spot should be reusable (DELETED → can be reclaimed)
        System.out.println("parkVehicle(\"NEW-0001\") → " + lot.parkVehicle("NEW-0001"));

        // Fill the lot to demonstrate load factor
        System.out.println("\n--- Filling lot to demonstrate load factor ---");
        int parked = 0;
        for (int i = 0; i < 400; i++) {
            String result = lot.parkVehicle("FILL-" + String.format("%04d", i));
            if (result.contains("Assigned")) parked++;
        }
        System.out.println("Parked " + parked + " additional vehicles");

        System.out.println("\ngetStatistics() → ");
        lot.getStatistics();
    }
}
