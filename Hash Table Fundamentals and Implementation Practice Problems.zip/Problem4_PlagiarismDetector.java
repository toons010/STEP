import java.util.*;

/**
 * Problem 4: Plagiarism Detection System
 * Concepts: String hashing, n-gram generation, frequency counting, HashMap<String, Set<DocId>>
 */
public class Problem4_PlagiarismDetector {

    private static final int N_GRAM_SIZE = 5; // 5-gram for good accuracy

    // n-gram string → set of document IDs that contain it
    private final Map<String, Set<String>> ngramIndex = new HashMap<>();
    // docId → list of n-grams
    private final Map<String, List<String>> docNgrams = new HashMap<>();

    /**
     * Index a document into the n-gram map
     */
    public void indexDocument(String docId, String content) {
        List<String> ngrams = extractNgrams(content, N_GRAM_SIZE);
        docNgrams.put(docId, ngrams);

        for (String ngram : ngrams) {
            ngramIndex.computeIfAbsent(ngram, k -> new HashSet<>()).add(docId);
        }

        System.out.println("Indexed \"" + docId + "\" → " + ngrams.size() + " n-grams");
    }

    /**
     * Analyse a document against the entire index
     */
    public void analyzeDocument(String docId, String content) {
        List<String> ngrams = extractNgrams(content, N_GRAM_SIZE);
        System.out.println("\nanalyzeDocument(\"" + docId + "\")");
        System.out.println("→ Extracted " + ngrams.size() + " n-grams");

        // Count matching n-grams per other document
        Map<String, Integer> matchCounts = new HashMap<>();
        for (String ngram : ngrams) {
            Set<String> docs = ngramIndex.getOrDefault(ngram, Collections.emptySet());
            for (String otherDoc : docs) {
                if (!otherDoc.equals(docId)) {
                    matchCounts.merge(otherDoc, 1, Integer::sum);
                }
            }
        }

        if (matchCounts.isEmpty()) {
            System.out.println("→ No matches found");
            return;
        }

        // Sort by match count descending
        matchCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEach(e -> {
                    double similarity = (e.getValue() * 100.0) / ngrams.size();
                    String verdict = similarity >= 50 ? "PLAGIARISM DETECTED" :
                                     similarity >= 15 ? "suspicious" : "similar";
                    System.out.printf("→ Found %d matching n-grams with \"%s\"%n", e.getValue(), e.getKey());
                    System.out.printf("→ Similarity: %.1f%% (%s)%n", similarity, verdict);
                });
    }

    /**
     * Extract n-grams (sliding window of n words)
     */
    private List<String> extractNgrams(String content, int n) {
        String[] words = content.toLowerCase()
                .replaceAll("[^a-z0-9 ]", " ")
                .trim()
                .split("\\s+");

        List<String> ngrams = new ArrayList<>();
        for (int i = 0; i <= words.length - n; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = i; j < i + n; j++) {
                if (j > i) sb.append(" ");
                sb.append(words[j]);
            }
            ngrams.add(sb.toString());
        }
        return ngrams;
    }

    /**
     * Compute hash for an n-gram (demonstrates string hashing)
     */
    public int computeHash(String ngram) {
        // Polynomial rolling hash
        int hash = 0;
        int prime = 31;
        int mod = 1_000_000_007;
        for (char c : ngram.toCharArray()) {
            hash = (int) (((long) hash * prime + c) % mod);
        }
        return hash;
    }

    /**
     * Benchmark: hash lookup vs linear search
     */
    public void benchmark(List<String> ngrams, String target) {
        // Hash lookup
        long start = System.nanoTime();
        boolean hashResult = ngramIndex.containsKey(target);
        long hashTime = System.nanoTime() - start;

        // Linear search
        start = System.nanoTime();
        boolean linearResult = false;
        for (String ng : ngrams) {
            if (ng.equals(target)) { linearResult = true; break; }
        }
        long linearTime = System.nanoTime() - start;

        System.out.printf("%nBenchmark for \"%s\":%n", target);
        System.out.printf("  Hash lookup:   %dns → found=%b%n", hashTime, hashResult);
        System.out.printf("  Linear search: %dns → found=%b%n", linearTime, linearResult);
        System.out.printf("  Speedup: %.1fx%n", (double) linearTime / hashTime);
    }

    public static void main(String[] args) {
        Problem4_PlagiarismDetector detector = new Problem4_PlagiarismDetector();

        System.out.println("=== Problem 4: Plagiarism Detection System ===\n");

        String doc089 = "The industrial revolution transformed the economic landscape of Europe. " +
                "New factories emerged across England bringing workers from rural areas. " +
                "Steam engines powered machinery changing the nature of production forever. " +
                "Urban populations grew rapidly creating new social challenges for governments.";

        String doc092 = "The industrial revolution dramatically transformed the economic landscape of Europe. " +
                "New factories quickly emerged across England bringing workers from rural areas. " +
                "Steam engines powered heavy machinery completely changing the nature of production forever. " +
                "Urban populations grew very rapidly creating enormous social challenges for governments everywhere.";

        String doc123 = "The industrial revolution transformed the economic landscape of Europe. " +
                "New factories emerged across England bringing workers from rural areas. " +
                "Steam engines powered machinery changing the nature of production forever. " +
                "Urban populations grew rapidly creating new social challenges for governments.";

        // Index existing documents
        detector.indexDocument("essay_089.txt", doc089);
        detector.indexDocument("essay_092.txt", doc092);

        // Analyse the new submission
        detector.analyzeDocument("essay_123.txt", doc123);

        // Show hash function
        System.out.println("\nHash of 'the industrial revolution transformed': "
                + detector.computeHash("the industrial revolution transformed"));

        // Benchmark
        List<String> allNgrams = detector.extractNgrams(doc089, N_GRAM_SIZE);
        detector.benchmark(allNgrams, "steam engines powered machinery changing");
    }
}
