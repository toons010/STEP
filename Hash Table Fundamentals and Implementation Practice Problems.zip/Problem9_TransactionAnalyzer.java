import java.util.*;
import java.util.stream.Collectors;

/**
 * Problem 9: Two-Sum Problem Variants for Financial Transactions
 * Concepts: HashMap complement lookup, O(1) performance, time-window filtering, K-Sum with memoisation
 */
public class Problem9_TransactionAnalyzer {

    static class Transaction {
        int    id;
        double amount;
        String merchant;
        String accountId;
        String time; // "HH:MM"

        Transaction(int id, double amount, String merchant, String accountId, String time) {
            this.id        = id;
            this.amount    = amount;
            this.merchant  = merchant;
            this.accountId = accountId;
            this.time      = time;
        }

        @Override public String toString() {
            return String.format("T(%d, $%.0f, %s, %s, %s)", id, amount, merchant, accountId, time);
        }
    }

    private final List<Transaction> transactions;

    public Problem9_TransactionAnalyzer(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    // ─── Utility ────────────────────────────────────────────────────────────

    /** Convert "HH:MM" → minutes from midnight */
    private int toMinutes(String time) {
        String[] parts = time.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    // ─── Problem Variants ───────────────────────────────────────────────────

    /**
     * Classic Two-Sum: find all pairs that sum to target.
     * O(n) using complement HashMap.
     */
    public List<int[]> findTwoSum(double target) {
        // amount → list of transaction ids with that amount
        Map<Double, List<Integer>> seen = new HashMap<>();
        List<int[]> result = new ArrayList<>();

        for (Transaction tx : transactions) {
            double complement = Math.round((target - tx.amount) * 100.0) / 100.0;
            if (seen.containsKey(complement)) {
                for (int otherId : seen.get(complement)) {
                    result.add(new int[]{otherId, tx.id});
                }
            }
            seen.computeIfAbsent(tx.amount, k -> new ArrayList<>()).add(tx.id);
        }
        return result;
    }

    /**
     * Two-Sum with time window: pairs must be within `windowMinutes` of each other.
     */
    public List<int[]> findTwoSumWithWindow(double target, int windowMinutes) {
        List<int[]> result = new ArrayList<>();
        for (int i = 0; i < transactions.size(); i++) {
            Transaction a = transactions.get(i);
            for (int j = i + 1; j < transactions.size(); j++) {
                Transaction b = transactions.get(j);
                double sum = Math.round((a.amount + b.amount) * 100.0) / 100.0;
                if (Math.abs(sum - target) < 0.01) {
                    int timeDiff = Math.abs(toMinutes(a.time) - toMinutes(b.time));
                    if (timeDiff <= windowMinutes) {
                        result.add(new int[]{a.id, b.id});
                    }
                }
            }
        }
        return result;
    }

    /**
     * K-Sum: find K transactions summing to target using recursion + HashMap memoisation.
     */
    public List<List<Integer>> findKSum(int k, double target) {
        List<Double> amounts = transactions.stream()
                .map(t -> t.amount).collect(Collectors.toList());
        List<Integer> ids = transactions.stream()
                .map(t -> t.id).collect(Collectors.toList());
        List<List<Integer>> result = new ArrayList<>();
        Map<String, List<List<Integer>>> memo = new HashMap<>();
        kSumHelper(amounts, ids, k, target, 0, new ArrayList<>(), result, memo);
        return result;
    }

    private void kSumHelper(List<Double> amounts, List<Integer> ids,
                             int k, double remaining, int start,
                             List<Integer> current, List<List<Integer>> result,
                             Map<String, List<List<Integer>>> memo) {
        if (k == 0) {
            if (Math.abs(remaining) < 0.01) result.add(new ArrayList<>(current));
            return;
        }
        String key = k + ":" + remaining + ":" + start;
        if (memo.containsKey(key)) return; // skip previously explored states

        for (int i = start; i < amounts.size(); i++) {
            current.add(ids.get(i));
            kSumHelper(amounts, ids, k - 1, Math.round((remaining - amounts.get(i)) * 100.0) / 100.0,
                    i + 1, current, result, memo);
            current.remove(current.size() - 1);
        }
        memo.put(key, new ArrayList<>(result));
    }

    /**
     * Duplicate detection: same amount + same merchant, different accounts.
     * O(n) using HashMap<"amount:merchant" → List<Transaction>>.
     */
    public List<Map<String, Object>> detectDuplicates() {
        Map<String, List<Transaction>> groups = new HashMap<>();
        for (Transaction tx : transactions) {
            String key = tx.amount + ":" + tx.merchant;
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(tx);
        }

        List<Map<String, Object>> duplicates = new ArrayList<>();
        for (Map.Entry<String, List<Transaction>> e : groups.entrySet()) {
            List<Transaction> group = e.getValue();
            // Collect distinct accounts in this group
            Set<String> accounts = new HashSet<>();
            for (Transaction t : group) accounts.add(t.accountId);
            if (accounts.size() > 1) {
                Map<String, Object> dup = new LinkedHashMap<>();
                dup.put("amount",   group.get(0).amount);
                dup.put("merchant", group.get(0).merchant);
                dup.put("accounts", new ArrayList<>(accounts));
                duplicates.add(dup);
            }
        }
        return duplicates;
    }

    public static void main(String[] args) {
        System.out.println("=== Problem 9: Two-Sum Variants for Financial Transactions ===\n");

        List<Transaction> txns = Arrays.asList(
            new Transaction(1, 500, "Store A", "acc1", "10:00"),
            new Transaction(2, 300, "Store B", "acc2", "10:15"),
            new Transaction(3, 200, "Store C", "acc3", "10:30"),
            new Transaction(4, 500, "Store A", "acc2", "11:05"),  // duplicate
            new Transaction(5, 150, "Store D", "acc4", "14:00"),
            new Transaction(6, 350, "Store E", "acc5", "14:10"),
            new Transaction(7, 100, "Store F", "acc6", "14:50")
        );

        Problem9_TransactionAnalyzer analyzer = new Problem9_TransactionAnalyzer(txns);

        // Classic Two-Sum
        System.out.println("findTwoSum(target=500) →");
        for (int[] pair : analyzer.findTwoSum(500)) {
            System.out.println("  (id:" + pair[0] + ", id:" + pair[1] + ")");
        }

        // Two-Sum with time window (60 min)
        System.out.println("\nfindTwoSumWithWindow(target=500, window=60min) →");
        for (int[] pair : analyzer.findTwoSumWithWindow(500, 60)) {
            System.out.println("  (id:" + pair[0] + ", id:" + pair[1] + ")");
        }

        // Duplicate detection
        System.out.println("\ndetectDuplicates() →");
        for (Map<String, Object> dup : analyzer.detectDuplicates()) {
            System.out.println("  " + dup);
        }

        // K-Sum
        System.out.println("\nfindKSum(k=3, target=1000) →");
        for (List<Integer> combo : analyzer.findKSum(3, 1000)) {
            System.out.println("  " + combo + "  // " +
                combo.stream().mapToDouble(id -> txns.stream()
                    .filter(t -> t.id == id).findFirst().get().amount).sum());
        }
    }
}
